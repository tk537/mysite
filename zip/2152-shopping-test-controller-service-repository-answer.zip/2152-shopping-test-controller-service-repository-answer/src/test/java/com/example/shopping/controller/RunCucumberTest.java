package com.example.shopping.controller;
import org.junit.platform.suite.api.ConfigurationParameter;
import org.junit.platform.suite.api.IncludeEngines;
import org.junit.platform.suite.api.SelectClasspathResource;
import org.junit.platform.suite.api.Suite;

import io.cucumber.junit.platform.engine.Constants;

@Suite
@IncludeEngines("cucumber")
@SelectClasspathResource("com/example/shopping/controller") // featureファイルの場所
@ConfigurationParameter(key = Constants.GLUE_PROPERTY_NAME, value = "com.example.shopping.controller") // ステップ定義のパッケージ
public class RunCucumberTest {

}
