package com.example.shopping.controller;

import io.cucumber.java.en.*;

public class StepDefinitions {
    @Given("テストの準備ができている")
    public void setup() {
        System.out.println("準備完了");
    }
    @When("テストを実行する")
    public void execute() {
        System.out.println("実行中...");
    }
    @Then("成功すること")
    public void check() {
        System.out.println("成功！");
    }
}