
-- OrderControllerIntegrationTest.sql の冒頭
DELETE FROM t_order_item; -- 外部参照されている場合は子テーブルから
DELETE FROM t_order;
DELETE FROM t_product;


INSERT INTO t_product
(id, name, price, stock) VALUES
('p01', '消しゴム', 100, 10)
,('p02', 'ノート', 200, 20)
,('p03', 'pname03', 300, 30)
,('p04', 'pname04', 400, 40)
,('p05', 'pname05', 500, 50)
;

