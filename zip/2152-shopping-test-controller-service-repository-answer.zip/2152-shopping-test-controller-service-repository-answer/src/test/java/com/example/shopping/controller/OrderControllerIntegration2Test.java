package com.example.shopping.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.transaction.annotation.Transactional;

import com.example.shopping.entity.Order;
import com.example.shopping.enumeration.PaymentMethod;
import com.example.shopping.input.CartInput;
import com.example.shopping.input.CartItemInput;
import com.example.shopping.input.OrderInput;

import io.cucumber.java.ja.ならば;
import io.cucumber.java.ja.もし;
import io.cucumber.java.ja.前提;
import io.cucumber.spring.CucumberContextConfiguration;
@CucumberContextConfiguration // これによりCucumberがSpringのBeanを認識します
@SpringBootTest
@AutoConfigureMockMvc
@Transactional
@Sql("OrderControllerIntegrationTest.sql")
public class OrderControllerIntegration2Test {

    @Autowired MockMvc mockMvc;
    @Autowired JdbcTemplate jdbcTemplate;

    private OrderInput orderInput = new OrderInput();
    private List<CartItemInput> cartItemInputs = new ArrayList<>();
    private MvcResult mvcResult;

    @前提("注文者が {string}、住所が {string} である")
    public void 注文者情報を設定(String name, String address) {
        orderInput.setName(name);
        orderInput.setAddress(address);
        orderInput.setPhone("090-0000-0000");
        orderInput.setEmailAddress("taro@example.com");
        orderInput.setPaymentMethod(PaymentMethod.CONVENIENCE_STORE);
    }

    @前提("カートに商品 {string} が {int} 個入っている")
    public void カートに商品を追加(String productId, int quantity) {
        CartItemInput item = new CartItemInput();
        item.setProductId(productId);
        // テスト簡略化のため名前や価格は固定（必要なら引数にする）
        item.setProductName(productId.equals("p01") ? "消しゴム" : "ノート");
        item.setProductPrice(productId.equals("p01") ? 100 : 200);
        item.setQuantity(quantity);
        cartItemInputs.add(item);
    }

    @もし("注文を確定する")
    public void 注文を確定する() throws Exception {
        CartInput cartInput = new CartInput();
        cartInput.setCartItemInputs(cartItemInputs);

        OrderSession orderSession = new OrderSession();
        orderSession.setOrderInput(orderInput);
        orderSession.setCartInput(cartInput);

        mvcResult = mockMvc.perform(
                post("/order/place-order")
                .param("order", "")
                .sessionAttr("scopedTarget.orderSession", orderSession)
        ).andReturn();
    }
/*
    @ならば("完了画面へリダイレクトされること")
    public void リダイレクト確認() throws Exception {
        assertThat(mvcResult.getResponse().getRedirectedUrl()).isEqualTo("/order/display-completion");
    }
    
*/
    @ならば("DBの注文者名が {string} であること")
    public void DB名確認(String expectedName) {
        Order order = (Order) mvcResult.getFlashMap().get("order");
        
        System.out.println("order id: "+order.getId());
        Map<String, Object> orderMap = jdbcTemplate.queryForMap("SELECT * FROM t_order WHERE id=?", order.getId());
//        assertThat(orderMap.get("customer_name")).isEqualTo(expectedName);
        assertEquals(expectedName, orderMap.get("customer_name"));
    }

    /*
    @ならば("商品 {string} の在庫が {int} であること")
    public void 在庫確認(String productId, int expectedStock) {
        int actualStock = jdbcTemplate.queryForObject("SELECT stock FROM t_product WHERE id=?", Integer.class, productId);
        assertThat(actualStock).isEqualTo(expectedStock);
    }

    @ならば("エラーメッセージ {string} が表示されること")
    public void エラー確認(String message) throws Exception {
        assertThat(mvcResult.getResponse().getContentAsString()).contains(message);
    }
    */
}